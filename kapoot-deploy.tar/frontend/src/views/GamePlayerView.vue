<template>
  <div class="game-player">
    <div class="player-header">
      <h1>Partie : {{ code }}</h1>
      <p v-if="pseudo" class="pseudo">Connecté en tant que {{ pseudo }}</p>
    </div>
    <p v-if="!connected && !connectionError" class="muted">Connexion en cours…</p>
    <p v-else-if="connectionError" class="error">{{ connectionError }}</p>
    <template v-else>
      <section v-if="currentQuestion" class="question-section">
        <p class="question-text">{{ currentQuestion.text }}</p>
        <p v-if="currentQuestion.allowMultiple" class="multi-hint">Plusieurs réponses possibles — sélectionnez toutes les bonnes réponses puis validez.</p>
        <ul v-if="currentQuestion.allowMultiple" class="choices choices-multi">
          <li v-for="c in currentQuestion.choices" :key="c.id" class="choice-item">
            <label class="choice-label">
              <input
                v-model="selectedChoiceIds"
                type="checkbox"
                :value="c.id"
                :disabled="answerSent"
                class="choice-checkbox"
              />
              <span class="choice-text">{{ c.text }}</span>
            </label>
          </li>
        </ul>
        <ul v-else class="choices">
          <li v-for="c in currentQuestion.choices" :key="c.id">
            <button
              type="button"
              class="choice-btn"
              :disabled="answerSent"
              @click="submitChoice(c.id)"
            >
              {{ c.text }}
            </button>
          </li>
        </ul>
        <div v-if="currentQuestion.allowMultiple && !answerSent" class="validate-row">
          <button
            type="button"
            class="btn btn-primary"
            :disabled="selectedChoiceIds.length === 0"
            @click="submitMultipleChoices"
          >
            Valider
          </button>
        </div>
      </section>
      <section v-else class="waiting-section">
        <p class="muted">{{ waitingMessage }}</p>
      </section>
      <section v-if="ranking.length" class="ranking">
        <h2>Classement</h2>
        <ol>
          <li v-for="(r, i) in ranking" :key="r.playerId">
            {{ i + 1 }}. {{ r.pseudo }} — {{ r.totalPoints }} pts
          </li>
        </ol>
      </section>
    </template>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRoute } from 'vue-router'
import * as signalR from '@microsoft/signalr'
import { createGameHubConnection } from '@/services/game-hub.service'

const route = useRoute()
const code = computed(() => String(route.params.code ?? '').toUpperCase())
const playerId = computed(() => (route.query.playerId as string) ?? '')

const pseudo = ref('')
const connection = ref<signalR.HubConnection | null>(null)
const connected = ref(false)
const connectionError = ref('')

interface QuestionChoice {
  id: string
  text: string
  order: number
}

interface ShowQuestionPayload {
  questionId: string
  text: string
  type: number
  order: number
  choices: QuestionChoice[]
  allowMultiple?: boolean
}

const currentQuestion = ref<ShowQuestionPayload | null>(null)
const answerSent = ref(false)
const gameEnded = ref(false)
const selectedChoiceIds = ref<string[]>([])

interface RankingEntry {
  playerId: string
  totalPoints: number
  rank?: number
  pseudo: string
}

const ranking = ref<RankingEntry[]>([])

function normalizeRanking(payload: unknown): RankingEntry[] {
  if (!Array.isArray(payload)) return []
  return payload.map((item: unknown) => {
    const o = item as Record<string, unknown>
    return {
      playerId: String(o.playerId ?? o.PlayerId ?? ''),
      totalPoints: Number(o.totalPoints ?? o.TotalPoints ?? 0),
      rank: o.rank !== undefined || o.Rank !== undefined ? Number(o.rank ?? o.Rank) : undefined,
      pseudo: String(o.pseudo ?? o.Pseudo ?? ''),
    }
  })
}

const waitingMessage = computed(() => {
  if (gameEnded.value) return 'Partie terminée.'
  if (currentQuestion.value) return ''
  return 'En attente de la prochaine question…'
})

onMounted(async () => {
  if (!playerId.value) {
    connectionError.value = 'Identifiant joueur manquant. Rejoignez depuis le tableau de bord.'
    return
  }
  const conn = createGameHubConnection(playerId.value)
  connection.value = conn

  conn.on('ShowQuestion', (payload: ShowQuestionPayload) => {
    currentQuestion.value = payload
    answerSent.value = false
    selectedChoiceIds.value = []
  })

  conn.on('ShowResult', () => {
    currentQuestion.value = null
  })

  conn.on('Ranking', (payload: unknown) => {
    ranking.value = normalizeRanking(payload)
  })

  conn.on('GameEnded', (payload: unknown) => {
    ranking.value = normalizeRanking(payload)
    gameEnded.value = true
    currentQuestion.value = null
  })

  try {
    await conn.start()
    await conn.invoke('JoinAsPlayer', code.value, playerId.value)
    connected.value = true
    connectionError.value = ''
    pseudo.value = route.query.pseudo as string || 'Joueur'
  } catch (e) {
    connectionError.value = e instanceof Error ? e.message : 'Connexion impossible.'
    connected.value = false
  }
})

onUnmounted(async () => {
  const conn = connection.value
  if (conn) {
    try {
      await conn.stop()
    } catch {
      // ignore
    }
    connection.value = null
  }
  connected.value = false
})

async function submitChoice(choiceId: string) {
  if (!currentQuestion.value || !connection.value || answerSent.value) return
  answerSent.value = true
  try {
    await connection.value.invoke('SubmitAnswer', currentQuestion.value.questionId, [choiceId])
  } catch {
    answerSent.value = false
  }
}

async function submitMultipleChoices() {
  if (!currentQuestion.value || !connection.value || answerSent.value || selectedChoiceIds.value.length === 0) return
  answerSent.value = true
  try {
    await connection.value.invoke('SubmitAnswer', currentQuestion.value.questionId, selectedChoiceIds.value)
  } catch {
    answerSent.value = false
  }
}
</script>

<style scoped>
.game-player {
  max-width: 560px;
}

.player-header {
  margin-bottom: 1.5rem;
}

.player-header h1 {
  margin: 0;
  font-size: 1.25rem;
}

.pseudo {
  margin: 0.25rem 0 0;
  color: var(--color-text-muted);
  font-size: 0.9rem;
}

.question-section {
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: var(--radius);
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  animation: fade-in-up 0.35s cubic-bezier(0.22, 1, 0.36, 1) both;
}

@keyframes fade-in-up {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.question-text {
  font-size: 1.1rem;
  margin: 0 0 1rem;
}

.multi-hint {
  font-size: 0.9rem;
  color: var(--color-text-muted);
  margin: 0 0 0.75rem;
}

.choices {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.choices-multi {
  gap: 0.5rem;
}

.choice-item {
  margin: 0;
}

.choice-label {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem 1rem;
  border: 1px solid var(--color-border);
  border-radius: var(--radius);
  background: var(--color-bg);
  cursor: pointer;
  transition: transform 0.2s ease, border-color 0.2s ease, background 0.2s ease, box-shadow 0.2s ease;
}

.choice-label:hover {
  border-color: var(--color-primary);
  background: rgba(124, 92, 255, 0.08);
  transform: translateX(4px);
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.15);
}

.choice-checkbox {
  width: 1.25rem;
  height: 1.25rem;
  accent-color: var(--color-primary);
}

.choice-text {
  flex: 1;
  color: var(--color-text);
  font-size: 1rem;
}

.validate-row {
  margin-top: 1rem;
}

.validate-row .btn {
  padding: 0.75rem 1.5rem;
  font-size: 1rem;
  border-radius: var(--radius);
  border: none;
  font-weight: 600;
  cursor: pointer;
  background: var(--color-primary);
  color: white;
  transition: transform 0.2s ease, box-shadow 0.25s ease, filter 0.2s ease;
}

.validate-row .btn:hover:not(:disabled) {
  filter: brightness(1.1);
  transform: translateY(-2px);
  box-shadow: 0 6px 24px rgba(124, 92, 255, 0.4);
}

.validate-row .btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.choice-btn {
  width: 100%;
  padding: 0.75rem 1rem;
  text-align: left;
  border: 1px solid var(--color-border);
  border-radius: var(--radius);
  background: var(--color-bg);
  color: var(--color-text);
  font-size: 1rem;
  cursor: pointer;
  transition: transform 0.2s ease, border-color 0.2s ease, background 0.2s ease, box-shadow 0.2s ease;
}

.choice-btn:hover:not(:disabled) {
  border-color: var(--color-primary);
  background: rgba(124, 92, 255, 0.1);
  transform: translateX(4px);
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.15);
}

.choice-btn:disabled {
  opacity: 0.7;
  cursor: default;
}

.waiting-section {
  margin-bottom: 1.5rem;
}

.ranking {
  margin-top: 1.5rem;
}

.ranking h2 {
  font-size: 1rem;
  margin-bottom: 0.5rem;
}

.ranking ol {
  padding-left: 1.25rem;
  color: var(--color-text-muted);
}

.muted {
  color: var(--color-text-muted);
}

.error {
  color: var(--color-error);
}
</style>
