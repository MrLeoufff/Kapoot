using Kapoot.Application.Interfaces;
using Kapoot.Domain.Entities;
using Kapoot.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Kapoot.Infrastructure.Repositories;

public class AnswerRepository(AppDbContext db) : IAnswerRepository
{
    public async Task<Answer?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default) =>
        await db.Answers.FindAsync([id], cancellationToken);

    public async Task<IReadOnlyList<Answer>> GetByPlayerAndQuestionAsync(Guid playerId, Guid questionId, CancellationToken cancellationToken = default) =>
        await db.Answers.Where(x => x.PlayerId == playerId && x.QuestionId == questionId).ToListAsync(cancellationToken);

    public async Task<Answer> AddAsync(Answer answer, CancellationToken cancellationToken = default)
    {
        db.Answers.Add(answer);
        await db.SaveChangesAsync(cancellationToken);
        return answer;
    }
}
